# OpenVPN Access Server With Unlimited Licences 
Make sure to install zip and unzip before executing the script 

<code>
Download the file openvpn_as_license_unlocker and execute as root 
---
cd /usr/src/
wget -O openvpn_as_license_unlocker https://raw.githubusercontent.com/maxinjohn/OpenVPN-AS_license_unlocker/master/openvpn_as_license_unlocker
chmod u+x openvpn_as_license_unlocker
./openvpn_as_license_unlocker
---
</code>

  **hooray**  start using OpenVPN-AS with unlimited licensees, when you update the OpenVPN-as server,  your license will be revoked. Make sure to run the script again to patch again.






###########################
![image](https://github.com/maxinjohn/OpenVPN-AS_license_unlocker/assets/33740873/4a4c85a1-2b70-40e2-a17f-c13d8b92091f)
